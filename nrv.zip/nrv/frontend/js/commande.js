'use strict';

const API_BASE = '';

let idCommande = null;

document.addEventListener('DOMContentLoaded', initialiserCommande);

async function initialiserCommande() {
    const resume = document.querySelector('#commande-resume');
    const formulaire = document.querySelector('#formulaire-paiement');
    const message = document.querySelector('#paiement-message');

    if (!resume || !formulaire || !message) {
        console.error('Éléments HTML manquants dans commande.html.');
        return;
    }

    try {
        await requete('/api/utilisateurs/me');

        const resultatPanier = await requete('/api/panier');
        const commande = resultatPanier.data ?? resultatPanier;

        if (
            !commande
            || !commande.id_commande
            || !Array.isArray(commande.articles)
            || commande.articles.length === 0
        ) {
            resume.textContent = 'Aucune commande en cours n’a été trouvée.';
            formulaire.hidden = true;
            return;
        }

        idCommande = Number(commande.id_commande);

        if (!Number.isInteger(idCommande) || idCommande < 1) {
            throw new Error('Identifiant de commande invalide.');
        }

        afficherCommande(commande);
    } catch (erreur) {
        console.error('Erreur de chargement de commande :', erreur);

        resume.textContent =
            erreur.message || 'Impossible de charger la commande.';

        formulaire.hidden = true;
    }
}

function afficherCommande(commande) {
    const resume = document.querySelector('#commande-resume');
    const identifiant = document.querySelector('#commande-identifiant');

    identifiant.textContent = `Commande n° ${commande.id_commande}`;
    resume.replaceChildren();

    const titre = document.createElement('h2');
    titre.textContent = 'Récapitulatif de la commande';
    resume.appendChild(titre);

    const liste = document.createElement('ul');

    for (const article of commande.articles) {
        const ligne = document.createElement('li');
        const nom = article.nom ?? 'Billet';
        const quantite = Number(article.quantite ?? 1);

        ligne.textContent =
            `${nom} — ${quantite} billet(s) — ` +
            `${libelleTarif(article.type_tarif)}`;

        liste.appendChild(ligne);
    }

    resume.appendChild(liste);

    const total = document.createElement('p');
    total.textContent =
        `Total : ${formatPrix(commande.montant_total)}`;

    resume.appendChild(total);
}

async function confirmerCommande(event) {
    event.preventDefault();

    const formulaire = event.currentTarget;
    const message = document.querySelector('#paiement-message');
    const bouton = formulaire.querySelector('[type="submit"]');

    if (!idCommande) {
        message.textContent = 'Aucune commande valide à confirmer.';
        return;
    }

    if (!formulaire.reportValidity()) {
        return;
    }

    bouton.disabled = true;
    message.textContent = 'Confirmation en cours…';

    try {
        const resultat = await requete(
            `/api/commandes/${idCommande}/paiement`,
            {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({}),
            }
        );

        const commande = resultat.data ?? resultat;
        const billets = Array.isArray(commande.billets)
            ? commande.billets
            : [];

        message.replaceChildren();

        const titre = document.createElement('h2');
        titre.textContent = 'Commande confirmée (simulation)';
        message.appendChild(titre);

        const details = document.createElement('p');
        details.textContent =
            `Commande n° ${commande.id_commande} — ` +
            `Montant : ${formatPrix(commande.montant_total)}.`;

        message.appendChild(details);

        const avertissement = document.createElement('p');
        avertissement.textContent =
            'Aucun paiement bancaire réel n’a été effectué.';

        message.appendChild(avertissement);

        if (billets.length === 0) {
            const sansBillet = document.createElement('p');
            sansBillet.textContent =
                'La commande est confirmée, mais aucun billet n’a été renvoyé.';
            message.appendChild(sansBillet);
        } else {
            const titreBillets = document.createElement('h3');
            titreBillets.textContent = 'Vos billets';
            message.appendChild(titreBillets);

            for (const billet of billets) {
                message.appendChild(creerElementBillet(billet));
            }
        }

        formulaire.hidden = true;
    } catch (erreur) {
        console.error('Erreur de confirmation :', erreur);

        message.textContent =
            erreur.message || 'La commande n’a pas pu être confirmée.';

        bouton.disabled = false;
    }
}

function creerElementBillet(billet) {
    const carte = document.createElement('article');
    carte.className = 'carte-billet';

    const nom = document.createElement('h4');
    nom.textContent = billet.nom_soiree ?? 'Billet NRV';
    carte.appendChild(nom);

    const reference = document.createElement('p');
    reference.textContent = `Référence : ${billet.reference}`;
    carte.appendChild(reference);

    const tarif = document.createElement('p');
    tarif.textContent =
        `Tarif : ${libelleTarif(billet.categorie_tarif)}`;
    carte.appendChild(tarif);

    if (!billet.token) {
        const erreur = document.createElement('p');
        erreur.textContent = 'Token manquant : le billet ne peut pas être ouvert.';
        carte.appendChild(erreur);
        return carte;
    }

    const urlBillet = new URL('/billet.html', window.location.origin);
    urlBillet.searchParams.set('token', billet.token);

    const lien = document.createElement('a');
    lien.href = urlBillet.href;
    lien.textContent = 'Ouvrir et imprimer ce billet';
    lien.target = '_blank';
    lien.rel = 'noopener noreferrer';
    carte.appendChild(lien);

    const qr = document.createElement('div');
    qr.className = 'billet-qr';
    qr.setAttribute('aria-label', `QR code du billet ${billet.reference}`);
    carte.appendChild(qr);

    if (typeof QRCode === 'undefined') {
        const indisponible = document.createElement('p');
        indisponible.textContent =
            'Le QR code n’a pas pu être chargé. Utilisez le lien du billet.';
        carte.appendChild(indisponible);
    } else {
        new QRCode(qr, {
            text: urlBillet.href,
            width: 160,
            height: 160,
            correctLevel: QRCode.CorrectLevel.M,
        });
    }

    return carte;
}

function libelleTarif(typeTarif) {
    const libelles = {
        normal: 'Normal',
        reduit: 'Réduit',
        pass_3_jours: 'Pass 3 jours',
        pass_3_jours_reduit: 'Pass 3 jours réduit',
    };

    return libelles[typeTarif] ?? 'Non précisé';
}

async function requete(chemin, options = {}) {
    const reponse = await fetch(`${API_BASE}${chemin}`, {
        ...options,
        credentials: 'same-origin',
        headers: {
            Accept: 'application/json',
            ...(options.headers ?? {}),
        },
    });

    const texte = await reponse.text();
    let resultat = {};

    if (texte) {
        try {
            resultat = JSON.parse(texte);
        } catch {
            throw new Error('Le serveur a renvoyé une réponse invalide.');
        }
    }

    if (!reponse.ok) {
        throw new Error(
            resultat.error
            ?? resultat.message
            ?? `Erreur HTTP ${reponse.status}`
        );
    }

    return resultat;
}

function formatPrix(montant) {
    return new Intl.NumberFormat('fr-FR', {
        style: 'currency',
        currency: 'EUR',
    }).format(Number(montant) || 0);
}

document.addEventListener('DOMContentLoaded', () => {
    const formulaire = document.querySelector('#formulaire-paiement');

    if (formulaire) {
        formulaire.addEventListener('submit', confirmerCommande);
    }
});